module.exports={
    SMS_API: process.env.SMS_API || 'A08d81e8883ac43c62871b785e6635408',
    VOICE_API: process.env.VOICE_API || 'Af1e9e669958a78c12e5b6525fdf291d7',
}